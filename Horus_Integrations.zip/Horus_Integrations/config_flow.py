"""Config flow y Options flow para Horus Integrations."""
import voluptuous as vol
from homeassistant import config_entries
from homeassistant.core import callback
from . import DOMAIN, SERVICE_UPDATE

class GithubUpdaterConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Maneja el flujo de configuración inicial."""

    VERSION = 1

    async def async_step_user(self, user_input=None):
        if self._async_current_entries():
            return self.async_abort(reason="single_instance_allowed")

        if user_input is not None:
            return self.async_create_entry(
                title="Horus Integrations", 
                data=user_input
            )

        data_schema = vol.Schema({
            vol.Required("default_folder"): str,
        })

        return self.async_show_form(step_id="user", data_schema=data_schema)

    @staticmethod
    @callback
    def async_get_options_flow(config_entry):
        """Crea el flujo de opciones para el botón Configurar."""
        return GithubUpdaterOptionsFlowHandler()


class GithubUpdaterOptionsFlowHandler(config_entries.OptionsFlow):
    """Maneja la ventana emergente del botón Configurar."""

    async def async_step_init(self, user_input=None):
        """Muestra el formulario y desencadena la descarga al guardar."""
        if user_input is not None:
            folder_name = user_input.get("default_folder")
            
            # 1. Actualiza los datos guardados en la entrada
            self.hass.config_entries.async_update_entry(
                self.config_entry,
                options=user_input
            )

            # 2. Llama al servicio de descarga inmediatamente
            await self.hass.services.async_call(
                DOMAIN,
                SERVICE_UPDATE,
                {"folder_name": folder_name},
                blocking=False
            )

            return self.async_create_entry(title="", data=user_input)

        # ❌ Se eliminó la lectura del valor previo 'current_folder'

        # ✅ Al NO definir 'default=...', el campo de texto se renderizará en blanco
        options_schema = vol.Schema({
            vol.Required("default_folder"): str,
        })

        return self.async_show_form(step_id="init", data_schema=options_schema)