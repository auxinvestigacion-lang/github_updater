"""Inicialización de Horus Integrations con descarga segura y dinámicas de UI."""
import os
import shutil
import logging
import aiohttp
import voluptuous as vol

from homeassistant.core import HomeAssistant, ServiceCall
from homeassistant.config_entries import ConfigEntry
import homeassistant.helpers.config_validation as cv

_LOGGER = logging.getLogger(__name__)

DOMAIN = "Horus_Integrations"
SERVICE_UPDATE = "update_component"

# Ajusta estas variables con los datos de tu repositorio
GITHUB_USER = "auxinvestigacion-lang"
GITHUB_REPO = "Horus_Integrations"
GITHUB_BRANCH = "main"

SERVICE_SCHEMA = vol.Schema({
    vol.Optional("folder_name"): cv.string,
})

async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Configura la integración leyendo los datos de la UI y Opciones."""

    async def handle_update_component(call: ServiceCall):
        # 1. Prioridad 1: Nombre pasado en la llamada del servicio
        folder_name = call.data.get("folder_name")

        # 2. Prioridad 2: Nombre configurado en el botón "CONFIGURAR" (options) o en la entrada inicial (data)
        if not folder_name:
            folder_name = entry.options.get(
                "default_folder", 
                entry.data.get("default_folder")
            )

        if not folder_name:
            _LOGGER.error("No se especificó ningún nombre de carpeta.")
            return

        folder_name = folder_name.strip()

        # Validación de seguridad para evitar traversals de rutas
        if "/" in folder_name or "\\" in folder_name or folder_name in [".", ".."]:
            _LOGGER.error("Nombre de carpeta no válido: '%s'", folder_name)
            return

        # 3. VERIFICACIÓN PREVIA EN GITHUB (Evita crear carpetas vacías si devuelve 404)
        api_url = f"https://api.github.com/repos/{GITHUB_USER}/{GITHUB_REPO}/contents/{folder_name}?ref={GITHUB_BRANCH}"
        headers = {
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "HomeAssistant-HorusIntegrations"
        }

        async with aiohttp.ClientSession() as session:
            async with session.get(api_url, headers=headers) as response:
                if response.status != 200:
                    _LOGGER.error(
                        "No se encontró la carpeta '%s' en GitHub (Código HTTP %s). No se creará ninguna carpeta local.",
                        folder_name, response.status
                    )
                    return

                files = await response.json()

            if not isinstance(files, list):
                _LOGGER.error("La ruta '%s' en GitHub no corresponde a una carpeta válida.", folder_name)
                return

            # 4. CREACIÓN / LIMPIEZA LOCAL (Solo se ejecuta si la carpeta existe en GitHub)
            custom_components_dir = hass.config.path("custom_components")
            target_component_dir = os.path.join(custom_components_dir, folder_name)

            if os.path.exists(target_component_dir):
                if os.path.isdir(target_component_dir):
                    _LOGGER.info("Eliminando versión previa de: %s", target_component_dir)
                    await hass.async_add_executor_job(shutil.rmtree, target_component_dir)
                else:
                    _LOGGER.warning("La ruta %s no es un directorio válido.", target_component_dir)
                    return

            os.makedirs(target_component_dir, exist_ok=True)

            # 5. DESCARGA DE ARCHIVOS
            for item in files:
                if item.get("type") == "file":
                    download_url = item.get("download_url")
                    file_name = item.get("name")
                    dest_file_path = os.path.join(target_component_dir, file_name)

                    async with session.get(download_url) as file_resp:
                        if file_resp.status == 200:
                            content = await file_resp.read()

                            def write_file():
                                with open(dest_file_path, "wb") as f:
                                    f.write(content)

                            await hass.async_add_executor_job(write_file)
                            _LOGGER.info("Archivo descargado: %s", file_name)

        _LOGGER.info("Carpeta '%s' actualizada con éxito desde GitHub.", folder_name)

    # Registro asíncrono del servicio
    if not hass.services.has_service(DOMAIN, SERVICE_UPDATE):
        hass.services.async_register(
            DOMAIN,
            SERVICE_UPDATE,
            handle_update_component,
            schema=SERVICE_SCHEMA
        )

    return True

async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Descarga la entrada de configuración."""
    return True